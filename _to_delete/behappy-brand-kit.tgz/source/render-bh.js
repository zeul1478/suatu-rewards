const { chromium } = require('playwright'); const fs = require('fs');
const S = f => fs.readFileSync('bh/svg/' + f, 'utf8');
const jobs = [
  ['favicon-16x16.png','favicon.svg',16,1,true],['favicon-32x32.png','favicon.svg',32,1,true],['favicon-48.png','favicon.svg',48,1,true],
  ['apple-touch-icon.png','app-icon.svg',180,1,false],['icon-192.png','app-icon.svg',192,1,false],['icon-512.png','app-icon.svg',512,1,false],
  ['icon-maskable-512.png','app-icon-maskable.svg',512,1,false],['og.png','og.svg',null,1,false],
  ['logo-light@2x.png','logo-light.svg',null,2,true],['logo-dark@2x.png','logo-dark.svg',null,2,true],
  ['powered-by-light@3x.png','powered-by-light.svg',null,3,true],['powered-by-dark@3x.png','powered-by-dark.svg',null,3,true],
];
(async () => { fs.mkdirSync('bh/png', { recursive: true }); const b = await chromium.launch();
  for (const [out, src, size, dpr, tr] of jobs) {
    let svg = S(src); const m = svg.match(/width="([\d.]+)" height="([\d.]+)"/);
    const W = size || Math.ceil(+m[1]), H = size || Math.ceil(+m[2]);
    svg = svg.replace(/width="[\d.]+" height="[\d.]+"/, `width="${W}" height="${H}"`);
    const ctx = await b.newContext({ deviceScaleFactor: dpr, viewport: { width: W, height: H } }); const p = await ctx.newPage();
    await p.setContent(`<html><body style="margin:0;background:transparent;line-height:0">${svg}</body></html>`);
    await p.screenshot({ path: 'bh/png/' + out, omitBackground: tr, clip: { x: 0, y: 0, width: W, height: H } }); await ctx.close(); }
  await b.close(); })();
