"""BeHappy company logo kit: 'Smile of points' symbol + outlined Inter wordmark."""
import math, os
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen

OUT = "bh/svg"; os.makedirs(OUT, exist_ok=True)
F = "node_modules/@fontsource/inter/files/inter-latin-{}-normal.woff"
R, B, M = TTFont(F.format(400)), TTFont(F.format(700)), TTFont(F.format(500))
TEAL, TEAL_D, TEAL_L, AMBER, INK, SLATE, WHITE = "#0f766e", "#115e59", "#ccfbf1", "#f59e0b", "#0f172a", "#475569", "#ffffff"


def text(font, s, size, x, base, track=0.0):
    sc = size / font["head"].unitsPerEm; cmap = font.getBestCmap(); gs = font.getGlyphSet()
    d, cur = [], x
    for ch in s:
        g = cmap[ord(ch)]
        pen = SVGPathPen(gs); gs[g].draw(TransformPen(pen, (sc, 0, 0, -sc, cur, base))); d.append(pen.getCommands())
        cur += font["hmtx"][g][0] * sc + track * size
    return " ".join(d), cur - track * size - x


def symbol(x, y, size, tile=TEAL, dot=WHITE, reward=AMBER, rx_ratio=0.25, tile_on=True, scale_dots=1.0, simple=False):
    """Rounded tile with five 'points' arranged as a smile; the last one is the reward."""
    s = size / 64
    out = [f'<rect x="{x}" y="{y}" width="{size}" height="{size}" rx="{size*rx_ratio:.2f}" fill="{tile}"/>'] if tile_on else []
    cx, cy, rad = 32, 18, 21
    angles = [150, 90, 30] if simple else [158, 124, 90, 56, 22]
    last = len(angles) - 1
    for i, a in enumerate(angles):
        t = math.radians(a)
        px, py = cx + rad * math.cos(t), cy + rad * math.sin(t)
        r = ((8.0 if i == last else 6.4) if simple else (6.0 if i == last else 4.4)) * scale_dots
        out.append(f'<circle cx="{x + px*s:.2f}" cy="{y + py*s:.2f}" r="{r*s:.2f}" fill="{reward if i == last else dot}"/>')
    return "".join(out)


def svg(w, h, body, bg=None, label="behappy"):
    bgr = f'<rect width="{w}" height="{h}" fill="{bg}"/>' if bg else ""
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w:.0f}" height="{h:.0f}" viewBox="0 0 {w:.2f} {h:.2f}" role="img" aria-label="{label}">{bgr}{body}</svg>\n'


def save(n, c): open(f"{OUT}/{n}", "w").write(c)


# Symbol files
save("symbol.svg", svg(64, 64, symbol(0, 0, 64)))
save("symbol-white.svg", svg(64, 64, symbol(0, 0, 64, tile=WHITE, dot=TEAL, reward=AMBER)))
save("symbol-mono.svg", svg(64, 64, symbol(0, 0, 64, tile="#000", dot="#fff", reward="#fff")))
save("favicon.svg", svg(64, 64, symbol(0, 0, 64, simple=True)))
save("app-icon.svg", svg(512, 512, symbol(0, 0, 512, rx_ratio=0)))
save("app-icon-maskable.svg", svg(512, 512, f'<rect width="512" height="512" fill="{TEAL}"/>' + symbol(102, 102, 308, tile_on=False)))


# Horizontal logo: symbol + "be" regular + "happy" bold
def lockup(text_be, text_happy, tile=TEAL, dot=WHITE):
    size = 64; fs = 52; base = 50
    be, wb = text(R, "be", fs, size + 16, base, -0.02)
    hp, wh = text(B, "happy", fs, size + 16 + wb + 1, base, -0.035)
    W = size + 16 + wb + 1 + wh
    return W, 66, symbol(0, 0, size, tile=tile, dot=dot) + f'<path d="{be}" fill="{text_be}"/><path d="{hp}" fill="{text_happy}"/>'

W, H, b = lockup(TEAL_D, INK); save("logo-light.svg", svg(W, H, b))
W, H, b = lockup("#99f6e4", WHITE); save("logo-dark.svg", svg(W, H, b))
W, H, b = lockup("#000", "#000", tile="#000"); save("logo-black.svg", svg(W, H, b))

# Wordmark only
be, wb = text(R, "be", 52, 0, 50, -0.02); hp, wh = text(B, "happy", 52, wb + 1, 50, -0.035)
save("wordmark-light.svg", svg(wb + 1 + wh, 66, f'<path d="{be}" fill="{TEAL_D}"/><path d="{hp}" fill="{INK}"/>'))

# "Powered by behappy" badge for store apps
def badge(label_c, be_c, hp_c, tile=TEAL, dot=WHITE):
    lab, wl = text(M, "Powered by", 11.5, 0, 16.5)
    be, wb = text(R, "be", 15, wl + 30, 17.5, -0.02); hp, wh = text(B, "happy", 15, wl + 30 + wb + 0.5, 17.5, -0.035)
    W = wl + 30 + wb + 0.5 + wh
    return W, 24, f'<path d="{lab}" fill="{label_c}"/>' + symbol(wl + 7, 2, 20, tile=tile, dot=dot) + f'<path d="{be}" fill="{be_c}"/><path d="{hp}" fill="{hp_c}"/>'

W, H, b = badge(SLATE, TEAL_D, INK); save("powered-by-light.svg", svg(W, H, b, label="Powered by behappy"))
W, H, b = badge("#94a3b8", "#99f6e4", WHITE); save("powered-by-dark.svg", svg(W, H, b, label="Powered by behappy"))

# Open Graph image (1200x630) — matches the landing page copy
h1, _ = text(B, "Turn first-time customers", 64, 96, 300, -0.025)
h2, _ = text(B, "into regulars", 64, 96, 378, -0.025)
sub, _ = text(R, "A simple loyalty & specials app for independent local shops.", 28, 96, 440)
btn, wbtn = text(B, "Join the waitlist", 26, 0, 0)
btn, _ = text(B, "Join the waitlist", 26, 96 + (330 - wbtn) / 2, 532)
og = (symbol(96, 96, 96, tile=WHITE, dot=TEAL, reward=AMBER) +
      f'<path d="{h1} {h2}" fill="{WHITE}"/><path d="{sub}" fill="{TEAL_L}"/>'
      f'<rect x="96" y="490" width="330" height="64" rx="32" fill="{AMBER}"/><path d="{btn}" fill="{INK}"/>')
lab, wl = text(M, "Powered by", 20, 0, 0)
lab, _ = text(M, "Powered by", 20, 1104 - wl - 172, 136)
be, wb = text(R, "be", 26, 1104 - 150, 138, -0.02); hp, wh = text(B, "happy", 26, 1104 - 150 + wb + 1, 138, -0.035)
og += f'<path d="{lab}" fill="{TEAL_L}"/><path d="{be}" fill="#99f6e4"/><path d="{hp}" fill="{WHITE}"/>'
save("og.svg", svg(1200, 630, og, bg=TEAL))
print(sorted(os.listdir(OUT)))
