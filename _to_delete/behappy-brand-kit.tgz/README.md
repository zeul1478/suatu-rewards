# BeHappy — company logo kit

The company behind the loyalty apps (the landing site's "Powered by BeHappy").
**Symbol:** a "smile of points" — five points in a smile on a teal tile; the last, bigger amber point is the reward. Same teal/amber as the landing page (`src/config/site.ts`), so it drops in without a redesign.
**Wordmark:** "be" Inter Regular (teal) + "happy" Inter Bold (ink), already outlined in every SVG.

| Color | Hex |
|---|---|
| Teal (brand) | `#0f766e` |
| Teal dark | `#115e59` |
| Amber (reward) | `#f59e0b` |
| Ink | `#0f172a` |

## Files → landing site (`Project X`)
| File | Goes to | Use |
|---|---|---|
| `svg/symbol.svg` | header logo (replaces the heart icon) | Works now while the site stays name-free |
| `svg/logo-light.svg` / `svg/logo-dark.svg` | header/footer if the name goes public | Symbol + "behappy" |
| `svg/favicon.svg` | `public/favicon.svg` | 3-point version, readable at 16 px |
| `png/favicon.ico`, `png/favicon-16x16.png`, `png/favicon-32x32.png` | `public/` | Older browsers |
| `png/apple-touch-icon.png` | `public/` | iPhone home screen |
| `png/icon-192.png`, `png/icon-512.png`, `png/icon-maskable-512.png` | `public/` + `site.webmanifest` | PWA / Android |
| `png/og.png` (`svg/og.svg`) | `public/og.png` | Link previews (same headline as the site) |
| `svg/powered-by-light.svg` / `-dark.svg` (+ `@3x` PNG) | store apps' footers (e.g. Suatu) | "Powered by behappy" credit |
| `svg/symbol-white.svg`, `svg/symbol-mono.svg`, `svg/logo-black.svg`, `svg/wordmark-light.svg` | — | Print, one-color, partners |

File names in `png/` match the ones already in `public/`, so replacing them is a straight swap. `scripts/generate-assets.mjs` currently draws the old heart — update or retire it so it doesn't overwrite these.

Status: concept — "BeHappy" not yet trademark-checked.
`source/behappy.py` regenerates the SVGs.
